"""
BAC Automation SUMMARY REPORT Generator
---------------------------------------
Generates a Summary Report from the 'BAC_AutomationSummary' sheet.
Aggregates records by 'Prctc' and normalized 'PortalRunStatus'
(using startswith match to ignore trailing claim IDs).

Output Sheet: 'SummaryReport'
"""

import os
import sys
import time
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment


class SummaryReportGenerator:
    """Generates a formatted SUMMARY REPORT from BAC_AutomationSummary."""

    def __init__(self, file_path, input_sheet="BAC_AutomationSummary", output_sheet="SummaryReport"):
        self.file_path = file_path
        self.input_sheet = input_sheet
        self.output_sheet = output_sheet

        # Excel styles
        self.bold_font = Font(bold=True)
        self.header_fill = PatternFill(start_color="DDEBF7", end_color="DDEBF7", fill_type="solid")  # pastel blue
        self.green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")  # total row
        self.thin_border = Border(
            left=Side(style="thin"), right=Side(style="thin"),
            top=Side(style="thin"), bottom=Side(style="thin")
        )
        self.center_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

        # Standardized PortalRunStatus categories
        self.status_prefixes = [
            "Success - Portal Msg Sent",
            "Success - Statement Note Sent",
            "Success - Skipped-Portal Msg - Already notified",
            "Success - Skipped - Statement Note - Already notified",
            "Failure - Action Required",
            "Failure - Action Required | No Provider found",
            "Failure - Action Required | No Department found",
            "Failure - Case not created | Incorrect provider",
            "Failure - Cannot Extract"
        ]

    # ----------------------------------------------------------------------
    def wait_for_file(self, timeout=20):
        """Ensure the file is accessible before processing."""
        print(f"Checking access to file: {self.file_path}")
        start_time = time.time()
        while True:
            try:
                if os.path.exists(self.file_path):
                    with open(self.file_path, "rb"):
                        print("File is accessible.")
                        return
            except Exception:
                pass
            if time.time() - start_time > timeout:
                raise TimeoutError(f"File not accessible after {timeout} seconds.")
            time.sleep(1)

    # ----------------------------------------------------------------------
    def normalize_PortalRunStatus(self, status):
        """Map PortalRunStatus text to standard prefix (ignore claim IDs)."""
        if pd.isna(status):
            return "Unknown"
        status = status.strip()
        for prefix in self.status_prefixes:
            if status.startswith(prefix):
                return prefix
        return "Other"

    # ----------------------------------------------------------------------
    def load_data(self):
        """Load data exclusively from 'BAC_AutomationSummary' sheet."""
        try:
            df = pd.read_excel(self.file_path, sheet_name=self.input_sheet, engine="openpyxl")
            df.columns = df.columns.str.strip()

            required = ["Prctc", "PortalRunStatus"]
            for col in required:
                if col not in df.columns:
                    raise KeyError(f"Missing required column: {col}")

            df["Prctc"] = df["Prctc"].fillna("Unknown")
            df["PortalRunStatus"] = df["PortalRunStatus"].astype(str).apply(self.normalize_PortalRunStatus)
            print(f"Data loaded from sheet '{self.input_sheet}' and normalized successfully.")
            return df
        except Exception as e:
            raise RuntimeError(f"Error loading Excel data: {e}")

    # ----------------------------------------------------------------------
    def aggregate_data(self, df):
        """Aggregate counts of each PortalRunStatus by Prctc."""
        summary_rows = []

        for market in df["Prctc"].unique():
            subset = df[df["Prctc"] == market]
            counts = {status: (subset["PortalRunStatus"] == status).sum() for status in self.status_prefixes}
            total = sum(counts.values())
            summary_rows.append([market, total] + list(counts.values()))

        columns = ["Market", "Total"] + self.status_prefixes
        summary_df = pd.DataFrame(summary_rows, columns=columns)

        # Add ALL Markets total row
        total_row = ["ALL Markets"] + summary_df.iloc[:, 1:].sum().tolist()
        summary_df.loc[len(summary_df)] = total_row
        print("Aggregation complete.")
        return summary_df

    # ----------------------------------------------------------------------
    def write_summary_report(self, summary_df):
        """Write the formatted SUMMARY REPORT to 'SummaryReport' sheet."""
        try:
            wb = load_workbook(self.file_path)
            if self.output_sheet in wb.sheetnames:
                del wb[self.output_sheet]
            ws = wb.create_sheet(self.output_sheet, 0)

            # Write header
            ws.append(summary_df.columns.tolist())
            for cell in ws[1]:
                cell.font = self.bold_font
                cell.fill = self.header_fill
                cell.border = self.thin_border
                cell.alignment = self.center_align

            # Write data rows
            for _, row in summary_df.iterrows():
                ws.append(row.tolist())

            # Style ALL Markets row
            for cell in ws[ws.max_row]:
                cell.font = self.bold_font
                cell.fill = self.green_fill
                cell.border = self.thin_border
                cell.alignment = self.center_align

            # Borders & alignment for all cells
            for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=1, max_col=ws.max_column):
                for cell in row:
                    cell.border = self.thin_border
                    cell.alignment = self.center_align

            # Auto column width
            for column_cells in ws.columns:
                length = max(len(str(cell.value)) if cell.value else 0 for cell in column_cells)
                ws.column_dimensions[column_cells[0].column_letter].width = min(length + 4, 60)

            ws.freeze_panes = "A2"
            wb.save(self.file_path)
            print(f"SUMMARY REPORT successfully written to '{self.output_sheet}'.")

        except PermissionError:
            raise PermissionError(f"Permission denied. Close {self.file_path} before running.")
        except Exception as e:
            raise RuntimeError(f"Error writing report: {e}")

    # ----------------------------------------------------------------------
    def run(self):
        """Execute the full SUMMARY REPORT generation pipeline."""
        print("Starting SUMMARY REPORT generation...")
        self.wait_for_file()
        df = self.load_data()
        summary_df = self.aggregate_data(df)
        self.write_summary_report(summary_df)
        print("SUMMARY REPORT generation completed successfully.")


# ----------------------------------------------------------------------
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python BAC_SummaryReport.py <excel_file_path>")
        sys.exit(1)

    file_path = sys.argv[1]
    SummaryReportGenerator(file_path).run()
