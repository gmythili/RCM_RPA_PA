import pandas as pd
import time
import sys
import os
from datetime import datetime

# ===================================================================
# FUNCTION: Wait until a file becomes available for reading
# ===================================================================
def wait_for_file(filepath, timeout=20):
    print(f"Waiting for file: {filepath}")

    if os.path.basename(filepath).startswith('~$'):
        print(f"Error: {filepath} is a temporary Excel lock file.")
        sys.exit(1)

    start_time = time.time()
    while True:
        try:
            if os.path.exists(filepath):
                with open(filepath, 'rb'):
                    print(f"File ready: {filepath}")
                    return
        except Exception:
            pass

        if time.time() - start_time > timeout:
            print(f"Timeout: Could not access file within {timeout} seconds -> {filepath}")
            sys.exit(1)

        time.sleep(1)

# ===================================================================
# SCRIPT START
# ===================================================================
print("Starting Eligibility_Claim_Sorting processing script...\n")
time.sleep(1)

# Validate command line arguments
if len(sys.argv) != 5:
    print(
        "Usage: python Eligibility_Claim_Sorting.py "
        "<eligibility_csv> <provider_excel> <inclusion_csv> <market_mapping_csv>"
    )
    sys.exit(1)

eligibility_csv_path = sys.argv[1]
provider_excel_path = sys.argv[2]
inclusion_csv_path = sys.argv[3]
market_mapping_csv_path = sys.argv[4]

# Ensure all input files are available
wait_for_file(eligibility_csv_path)
wait_for_file(provider_excel_path)
wait_for_file(inclusion_csv_path)
wait_for_file(market_mapping_csv_path)

# ===================================================================
# READ ELIGIBILITY CSV
# ===================================================================
try:
    with open(eligibility_csv_path, 'r', encoding='utf-8') as f:
        first_line = f.readline().strip()

    skip_rows = 1 if first_line.lower().startswith("report name") else 0
    df = pd.read_csv(eligibility_csv_path, skiprows=skip_rows)
    df.columns = df.columns.str.strip().str.lower()
except Exception as e:
    print(f"Error reading eligibility file: {e}")
    sys.exit(1)

if 'dos' not in df.columns:
    df['dos'] = ''

required_columns = [
    "patientid",
    "curr athena kick code",
    "claimid",
    "prctc",
    "patient name",
    "sup prvdr",
    "sprsvng prvdr prvdr grp",
    "dos"
]
for col in required_columns:
    if col not in df.columns:
        print(f"Error: Required column missing: {col}")
        sys.exit(1)

# ===================================================================
# FILTER BAC RECORDS
# ===================================================================
try:
    df_bac = df[df["curr athena kick code"].astype(str).str.contains("BAC", na=False)].copy()
except Exception as e:
    print(f"Error filtering BAC records: {e}")
    sys.exit(1)

# ===================================================================
# PROVIDER NAME MAPPING
# ===================================================================
try:
    providers = pd.read_excel(provider_excel_path)
    providers.columns = providers.columns.str.strip()
    provider_map = dict(zip(providers["Scheduling Name"], providers["Billed Name"]))
    df_bac["Provider_Billed_Name"] = df_bac["sup prvdr"].map(provider_map).fillna("No provider found")
except Exception as e:
    print(f"Warning: Provider mapping failed: {e}")

# ===================================================================
# INCLUSION LOGIC
# ===================================================================
excluded_records = []

try:
    inclusion_df = pd.read_csv(inclusion_csv_path)
    inclusion_df.columns = inclusion_df.columns.str.strip().str.lower()
    inclusion_df = inclusion_df[["departname", "prctc"]].dropna()

    inclusion_pairs = set(
        zip(
            inclusion_df["departname"].astype(str).str.strip().str.lower(),
            inclusion_df["prctc"].astype(str).str.strip().str.lower()
        )
    )

    def is_included(row):
        return (
            str(row["sprsvng prvdr prvdr grp"]).strip().lower(),
            str(row["prctc"]).strip().lower()
        ) in inclusion_pairs

    inclusion_mask = df_bac.apply(is_included, axis=1)
    excluded_records.append(df_bac[~inclusion_mask])
    df_bac = df_bac[inclusion_mask].copy()

except Exception as e:
    print(f"Warning: Inclusion logic failed; no inclusion filtering applied. {e}")

# ===================================================================
# PORTALTERMSYN EXCLUSION
# ===================================================================
try:
    if "portaltermsyn" in df_bac.columns:
        portal_excluded = df_bac[df_bac["portaltermsyn"].astype(str).str.lower() == "n"]
        excluded_records.append(portal_excluded)
        df_bac = df_bac[df_bac["portaltermsyn"].astype(str).str.lower() != "n"].copy()
except Exception as e:
    print(f"Warning: PortalTermsyn exclusion failed: {e}")

# ===================================================================
# MARKET MAPPING
# ===================================================================
try:
    market_df = pd.read_csv(market_mapping_csv_path, encoding="latin1")
    market_df.columns = market_df.columns.str.strip().str.lower()
    market_map = dict(
        zip(
            market_df["prctc_abbr"].astype(str).str.strip(),
            market_df["market_name"].astype(str).str.strip()
        )
    )
except Exception as e:
    print(f"Warning: Market mapping failed: {e}")
    market_map = {}

# ===================================================================
# DETERMINE EXCEL SHEET NAMES
# ===================================================================
df_bac["sheet_name"] = ""
market_name_to_abbr = {str(v).strip().lower(): str(k).strip() for k, v in market_map.items()}
for idx, row in df_bac.iterrows():
    prctc_value = str(row["prctc"]).strip().lower()
    if prctc_value in market_name_to_abbr:
        df_bac.at[idx, "sheet_name"] = market_name_to_abbr[prctc_value]

# ===================================================================
# OUTPUT FILE PATHS
# ===================================================================
output_file = os.path.join(
    os.path.dirname(eligibility_csv_path),
    f"BAC_AutomationReport_{datetime.now().strftime('%Y%m%d')}.xlsx"
)

# ===================================================================
# WRITE MAIN BAC OUTPUT
# ===================================================================
try:
    with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
        for sheet, group in df_bac[df_bac["sheet_name"] != ""].groupby("sheet_name"):
            safe_sheet_name = sheet[:31]
            group.sort_values(by="patient name").to_excel(writer, sheet_name=safe_sheet_name, index=False)

        summary_columns = [
            "Prctc",
            "PatientID",
            "Patient name",
            "ApptDate",
            "Kickcode",
            "PatientNoteStatus",
            "PortalRunStatus"
        ]
        pd.DataFrame(columns=summary_columns).to_excel(writer, sheet_name="BAC_AutomationSummary", index=False)

    print(f"Main BAC output generated: {output_file}")

except Exception as e:
    print(f"Error writing main BAC output: {e}")
    sys.exit(1)

# ===================================================================
# WRITE EXCLUSION FILE WITH REASONS, SUMMARY, AND OVERVIEW
# ===================================================================
all_excluded_list = []

# Add exclusion reasons
if len(excluded_records) >= 1 and not excluded_records[0].empty:
    df_inc_excluded = excluded_records[0].copy()
    df_inc_excluded["ExclusionReason"] = "Not opted in BAC Pilot"
    all_excluded_list.append(df_inc_excluded)

if len(excluded_records) >= 2 and not excluded_records[1].empty:
    df_portal_excluded = excluded_records[1].copy()
    df_portal_excluded["ExclusionReason"] = "PortalTermsyn = N"
    all_excluded_list.append(df_portal_excluded)

if all_excluded_list:
    all_excluded_df = pd.concat(all_excluded_list, ignore_index=True)
else:
    all_excluded_df = pd.DataFrame()

if not all_excluded_df.empty:
    exclusion_file = os.path.join(
        os.path.dirname(eligibility_csv_path),
        f"Exclusion_BAC_{datetime.now().strftime('%Y%m%d')}.xlsx"
    )

    try:
        with pd.ExcelWriter(exclusion_file, engine="openpyxl") as writer:

            # Exclusion sheet with reason
            all_excluded_df.to_excel(writer, sheet_name="Exclusion", index=False)

            # Summary sheet
            summary_df = (
                all_excluded_df
                .groupby(["prctc", "sprsvng prvdr prvdr grp", "ExclusionReason"])
                .size()
                .reset_index(name="count")
                .rename(columns={"sprsvng prvdr prvdr grp": "Departname"})
            )
            total_row = pd.DataFrame({
                "prctc": ["Total"],
                "Departname": [""],
                "ExclusionReason": [""],
                "count": [summary_df["count"].sum()]
            })
            summary_df = pd.concat([summary_df, total_row], ignore_index=True)
            summary_df.to_excel(writer, sheet_name="Summary", index=False)

            # Overview sheet with counts per exclusion reason
            overview_data = [
                {"PatientRecord": "Initial Records", "Count": df.shape[0]},
                {"PatientRecord": "Included Records", "Count": df_bac.shape[0]},
                {"PatientRecord": "Excluded Records", "Count": all_excluded_df.shape[0]}
            ]

            reason_counts = all_excluded_df.groupby("ExclusionReason").size().reset_index(name="Count")
            for idx, row in reason_counts.iterrows():
                overview_data.append({"PatientRecord": f"Excluded Reason: {row['ExclusionReason']}", "Count": row["Count"]})

            overview_df = pd.DataFrame(overview_data)
            overview_df.to_excel(writer, sheet_name="OverallSummary", index=False)

        print(f"Exclusion file generated with Exclusion, Summary, and Overview sheets: {exclusion_file}")

    except Exception as e:
        print(f"Error writing exclusion file: {e}")
else:
    print("No records were excluded; exclusion file not generated.")

print("Script completed successfully.")