import pandas as pd
import sys
import os
import time
from datetime import datetime

# ============================================================== 
# FUNCTION: Wait for input files to be ready 
# ============================================================== 
def wait_for_file(filepath, timeout=20):
    print(f"[INFO] Waiting for file: {filepath}")

    if os.path.basename(filepath).startswith('~$'):
        print(f"[ERROR] {filepath} is a temporary Excel lock file.")
        sys.exit(1)

    start_time = time.time()

    while True:
        try:
            if os.path.exists(filepath):
                with open(filepath, 'rb'):
                    print(f"[INFO] File ready: {filepath}")
                    return
        except Exception:
            pass

        if time.time() - start_time > timeout:
            print(f"[ERROR] Timeout: File not accessible after {timeout} seconds -> {filepath}")
            sys.exit(1)

        time.sleep(1)

# ============================================================== 
# COMMAND LINE ARGUMENTS 
# ============================================================== 
if len(sys.argv) != 5:
    print("Usage: python OSB_Preprocessing_V7.py <input_csv> <provider_excel> <inclusion_csv> <market_mapping_csv>")
    sys.exit(1)

input_csv = sys.argv[1]
provider_excel = sys.argv[2]
inclusion_csv = sys.argv[3]
market_mapping_csv = sys.argv[4]

# Wait for files to be ready
wait_for_file(input_csv)
wait_for_file(provider_excel)
wait_for_file(inclusion_csv)
wait_for_file(market_mapping_csv)

# ============================================================== 
# READ INPUT CSV (robust handling of encoding + Report Name row)
# ============================================================== 
try:

    encodings_to_try = ['utf-8', 'cp1252', 'latin1']

    df = None
    detected_encoding = None

    for enc in encodings_to_try:
        try:

            with open(input_csv, 'r', encoding=enc, errors='replace') as f:
                first_line = f.readline().strip()

            skip_rows = 1 if first_line.lower().startswith("report name") else 0

            df = pd.read_csv(
                input_csv,
                skiprows=skip_rows,
                sep=None,
                engine='python',
                quotechar='"',
                encoding=enc
            )

            detected_encoding = enc

            print(f"[INFO] Successfully read CSV using encoding: {enc}")
            break

        except Exception as inner_e:
            print(f"[WARNING] Failed with encoding {enc}: {inner_e}")

    if df is None:
        raise Exception("Unable to read CSV with supported encodings.")

    df.columns = df.columns.str.strip().str.lower()

except Exception as e:
    print(f"[ERROR] Error reading input CSV: {e}")
    sys.exit(1)

# ============================================================== 
# INITIAL INFO
# ============================================================== 
print(f"[INFO] Columns detected: {df.columns.tolist()}")
print(f"[INFO] Initial records: {df.shape[0]}")

initial_record_count = df.shape[0]

# ============================================================== 
# FILTER 1: Remove rows where portaltermsyn = 'N'
# ============================================================== 
df_portal_removed = df.iloc[0:0].copy()

if 'portaltermsyn' in df.columns:

    portal_mask = (
        df['portaltermsyn']
        .astype(str)
        .str.strip()
        .str.lower() == 'n'
    )

    df_portal_removed = df[portal_mask].copy()
    df = df[~portal_mask].copy()

else:
    print("[WARNING] Column 'portaltermsyn' not found; skipping this filter.")

print(f"[INFO] PortalTermsyn = N removed: {df_portal_removed.shape[0]}")
print(f"[INFO] Remaining after PortalTermsyn filter: {df.shape[0]}")

# ============================================================== 
# FILTER 2: Remove rows where patient hold stmt reason is non-empty
# ============================================================== 
df_hold_stmt_removed = df.iloc[0:0].copy()

hold_col = 'patient hold stmt reason'

if hold_col in df.columns:

    hold_mask = (
        df[hold_col].notna() &
        df[hold_col].astype(str).str.strip().ne('')
    )

    df_hold_stmt_removed = df[hold_mask].copy()
    df = df[~hold_mask].copy()

    print(f"[INFO] Non-empty '{hold_col}' removed: {df_hold_stmt_removed.shape[0]}")
    print(f"[INFO] Remaining after Hold Stmt filter: {df.shape[0]}")

else:
    print(f"[WARNING] Column '{hold_col}' not found; skipping this filter.")
    print(f"[INFO] Available columns: {df.columns.tolist()}")

# ============================================================== 
# REMOVE DUPLICATES BASED ON (prctc + patientid)
# ============================================================== 
if {'prctc', 'patientid'}.issubset(df.columns):

    dup_mask = df.duplicated(
        subset=['prctc', 'patientid'],
        keep='first'
    )

    df_duplicates = df[dup_mask].copy()
    df = df[~dup_mask].copy()

else:
    df_duplicates = df.iloc[0:0].copy()

print(f"[INFO] Duplicates removed: {df_duplicates.shape[0]}")
print(f"[INFO] Remaining after duplicate removal: {df.shape[0]}")

# ============================================================== 
# INCLUSION LIST HANDLING
# ============================================================== 
try:

    inclusion_df = pd.read_csv(inclusion_csv)

    inclusion_df.columns = (
        inclusion_df.columns
        .str.strip()
        .str.lower()
    )

    if 'msggrp' not in inclusion_df.columns:
        print("[WARNING] 'MsgGrp' column not found in inclusion CSV; defaulting all to 'A'")
        inclusion_df['msggrp'] = 'A'

    inclusion_pairs = set(zip(
        inclusion_df['departname'].astype(str).str.strip().str.lower(),
        inclusion_df['prctc'].astype(str).str.strip().str.lower(),
        inclusion_df['msggrp'].astype(str).str.strip().str.upper()
    ))

    df_included = df.iloc[0:0].copy()
    df_excluded = df.iloc[0:0].copy()

    if {'sprsvng prvdr prvdr grp', 'prctc'}.issubset(df.columns):

        def get_msggrp(x):

            for _, row in inclusion_df.iterrows():

                if (
                    str(x['sprsvng prvdr prvdr grp']).strip().lower() ==
                    str(row['departname']).strip().lower()
                    and
                    str(x['prctc']).strip().lower() ==
                    str(row['prctc']).strip().lower()
                ):
                    return str(row['msggrp']).strip().upper()

            return 'A'

        def is_included(x):

            key = (
                str(x['sprsvng prvdr prvdr grp']).strip().lower(),
                str(x['prctc']).strip().lower(),
                get_msggrp(x)
            )

            return key in inclusion_pairs

        mask = df.apply(is_included, axis=1)

        df_included = df[mask].copy()

        df_included['MsgGrp'] = df_included.apply(get_msggrp, axis=1)

        df_excluded = df[~mask].copy()

    else:
        print("[WARNING] Required columns ('sprsvng prvdr prvdr grp', 'prctc') not found.")

        df_excluded = df.copy()
        df_included = df.iloc[0:0].copy()

except Exception as e:

    print(f"[WARNING] Inclusion file processing failed; including all records. {e}")

    df_included = df.copy()
    df_included['MsgGrp'] = 'A'

    df_excluded = df.iloc[0:0].copy()

print(f"[INFO] Included records: {df_included.shape[0]}")
print(f"[INFO] Not included records: {df_excluded.shape[0]}")

# ============================================================== 
# PROVIDER MAPPING
# ============================================================== 
try:

    providers = pd.read_excel(provider_excel)

    providers.columns = providers.columns.str.strip()

    providers = providers[
        ['Scheduling Name', 'Billed Name', 'Market']
    ].dropna()

    providers['Scheduling Name'] = (
        providers['Scheduling Name']
        .astype(str)
        .str.strip()
    )

    providers['Market'] = (
        providers['Market']
        .astype(str)
        .str.strip()
    )

    df_included['prim prvdr'] = (
        df_included['prim prvdr']
        .astype(str)
        .str.strip()
    )

    df_included['prctc'] = (
        df_included['prctc']
        .astype(str)
        .str.strip()
    )

    if {'prim prvdr', 'prctc'}.issubset(df_included.columns):

        df_included = df_included.merge(
            providers,
            how='left',
            left_on=['prim prvdr', 'prctc'],
            right_on=['Scheduling Name', 'Market']
        )

        df_included['Provider_Billed_Name'] = (
            df_included['Billed Name']
            .fillna("No provider found")
        )

        df_included.drop(
            columns=['Scheduling Name', 'Billed Name', 'Market'],
            inplace=True,
            errors='ignore'
        )

except Exception as e:
    print(f"[WARNING] Provider mapping failed - {e}")

# ============================================================== 
# MARKET MAPPING
# ============================================================== 
try:

    market_map = pd.read_csv(market_mapping_csv)

    market_map.columns = (
        market_map.columns
        .str.strip()
        .str.lower()
    )

    market_dict = dict(zip(
        market_map['prctc_abbr'].astype(str).str.strip(),
        market_map['market_name'].astype(str).str.strip()
    ))

except Exception as e:

    print(f"[WARNING] Market mapping failed - {e}")
    market_dict = {}

# ============================================================== 
# CREATE PROCESSED OSB EXCEL SPLIT BY MsgGrp
# ============================================================== 
today_str = datetime.now().strftime('%Y%m%d')

msggrp_filename_map = {
    'A': f"Patient Billing Balance Reminders_{today_str}_DefaultMsg.xlsx",
    'B': f"Patient Billing Balance Reminders_{today_str}_SpecialMsg.xlsx",
    'C': f"Patient Billing Balance Reminders_{today_str}_PartC.xlsx"
}

for msggrp, filename in msggrp_filename_map.items():

    part_df = df_included[
        df_included['MsgGrp'].str.upper() == msggrp
    ]

    processed_osb_path = os.path.join(
        os.path.dirname(input_csv),
        filename
    )

    with pd.ExcelWriter(processed_osb_path, engine='openpyxl') as writer:

        sheet_names_used = set()

        if not part_df.empty:

            for prctc_value, group in part_df.groupby('prctc'):

                sheet_name = str(prctc_value).strip()

                for abbr, market_name in market_dict.items():

                    if sheet_name.lower() == market_name.lower():
                        sheet_name = abbr
                        break

                for ch in ['\\', '/', '*', '?', ':', '[', ']']:
                    sheet_name = sheet_name.replace(ch, '_')

                sheet_name = sheet_name[:31]

                original_sheet_name = sheet_name
                counter = 1

                while sheet_name in sheet_names_used:
                    sheet_name = f"{original_sheet_name}_{counter}"[:31]
                    counter += 1

                sheet_names_used.add(sheet_name)

                if 'patient name' in group.columns:
                    group = group.sort_values(
                        by='patient name',
                        ascending=True,
                        na_position='last'
                    )

                group.to_excel(
                    writer,
                    sheet_name=sheet_name,
                    index=False
                )

        summary_headers = [
            "Prctc",
            "PatientID",
            "Patient name",
            "BillingDate",
            "Outstanding Balance",
            "PatientNoteStatus",
            "PortalRunStatus"
        ]

        pd.DataFrame(columns=summary_headers).to_excel(
            writer,
            sheet_name="OSB_AutomationSummary",
            index=False
        )

    print(f"[INFO] Processed OSB Excel saved as: {processed_osb_path}")

# ============================================================== 
# CREATE EXCLUSION REPORT
# ============================================================== 
print("[INFO] Creating exclusion report...")

excluded_frames = []

# PortalTermsyn
if not df_portal_removed.empty:

    df_portal_tagged = df_portal_removed.copy()

    df_portal_tagged['ExclusionReason'] = 'PortalTermsync = N'

    excluded_frames.append(df_portal_tagged)

# Hold Statement
if not df_hold_stmt_removed.empty:

    df_hold_tagged = df_hold_stmt_removed.copy()

    df_hold_tagged['ExclusionReason'] = 'Non-Empty Patient Hold Statement Reason'

    excluded_frames.append(df_hold_tagged)

# Not Included
if not df_excluded.empty:

    df_not_included = df_excluded.copy()

    df_not_included['ExclusionReason'] = 'Not opted for Patient Balance Reminders Pilot'

    excluded_frames.append(df_not_included)

# Combine
if excluded_frames:

    df_combined_excluded = pd.concat(
        excluded_frames,
        ignore_index=True
    )

else:

    df_combined_excluded = pd.DataFrame(
        columns=df.columns.tolist() + ['ExclusionReason']
    )

# Overview Summary
overview_data = {
    "PatientRecord": [
        "Initial Records",
        "PortalTermsync N Removed",
        "Non-Empty Patient Hold Statement Removed",
        "Duplicates Removed",
        "Excluded Records",
        "Records to be processed"
    ],
    "Count": [
        initial_record_count,
        df_portal_removed.shape[0],
        df_hold_stmt_removed.shape[0],
        df_duplicates.shape[0],
        df_combined_excluded.shape[0],
        df_included.shape[0]
    ]
}

df_overview = pd.DataFrame(overview_data)

# ============================================================== 
# WRITE EXCLUSION REPORT
# ============================================================== 
exclusion_report_path = os.path.join(
    os.path.dirname(input_csv),
    f"Exclusion_Report_{today_str}.xlsx"
)

with pd.ExcelWriter(exclusion_report_path, engine='openpyxl') as writer:

    # Sheet 1
    if not df_combined_excluded.empty:

        df_combined_excluded.to_excel(
            writer,
            sheet_name="Exclusion_Data",
            index=False
        )

        group_cols = [
            c for c in [
                'ExclusionReason',
                'prctc',
                'sprsvng prvdr prvdr grp'
            ]
            if c in df_combined_excluded.columns
        ]

        if group_cols:

            report_summary = (
                df_combined_excluded
                .groupby(group_cols, as_index=False)
                .size()
                .rename(columns={'size': 'Total_Count'})
            )

            report_summary.to_excel(
                writer,
                sheet_name="ExclusionSummary",
                index=False
            )

    # Sheet 3
    df_overview.to_excel(
        writer,
        sheet_name="OverallRecordSummary",
        index=False
    )

print(f"[INFO] Exclusion Report saved at: {exclusion_report_path}")

print("[INFO] OSB preprocessing completed successfully.")