"""
Enhanced Report Generator for OSB Automation Summary
----------------------------------------------------
Generates a summary Excel report aggregating PortalRunStatus counts
by market and status, including totals, formatting, pastel header styling,
and auto-fit column widths.
"""

import os
import sys
import time
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment


class ReportGenerator:
    """Generates a formatted Excel summary report from OSB Automation data."""

    def __init__(self, file_path, sheet_name="SummaryReport"):
        self.file_path = file_path
        self.sheet_name = sheet_name

        # Excel formatting styles
        self.bold_font = Font(bold=True)
        self.header_fill = PatternFill(start_color="DDEBF7", end_color="DDEBF7", fill_type="solid")  # Pastel blue
        self.green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")  # Light green
        self.thin_border = Border(
            left=Side(style="thin"), right=Side(style="thin"),
            top=Side(style="thin"), bottom=Side(style="thin")
        )
        self.center_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

        # Expected PortalRunStatus categories
        self.status_categories = [
            "Success - Portal Msg Sent",
            "Success - No portal access",
            "Success - Skipped-Portal Msg-Already notified",
            "Failure - Action Required",
            "Failure - Action Required | No Provider found",
            "Failure - Action Required | No Patient found",
            "Failure - Action Required | No Department found",
            "Failure - Case not created | Incorrect provider"
        ]

    # -------------------------------------------------------------------------
    def wait_for_file(self, timeout=20):
        """Wait until the Excel file is ready for reading."""
        print(f"Checking file access for: {self.file_path}")
        if os.path.basename(self.file_path).startswith("~$"):
            raise RuntimeError(f"The file {self.file_path} appears to be a temporary Excel lock file.")

        start_time = time.time()
        while True:
            try:
                if os.path.exists(self.file_path):
                    with open(self.file_path, "rb"):
                        print("File is accessible.")
                        return
            except Exception:
                pass

            if time.time() - start_time > timeout:
                raise TimeoutError(f"File not accessible after {timeout} seconds: {self.file_path}")
            time.sleep(1)

    # -------------------------------------------------------------------------
    def load_data(self):
        """Load the Excel data safely."""
        try:
            df = pd.read_excel(self.file_path, sheet_name="OSB_AutomationSummary", engine="openpyxl")
            df.columns = df.columns.str.strip()

            # Ensure necessary columns exist
            required_cols = ["Prctc", "PortalRunStatus"]
            for col in required_cols:
                if col not in df.columns:
                    raise KeyError(f"Missing required column: {col}")

            df["Prctc"] = df["Prctc"].fillna("Unknown")
            df["PortalRunStatus"] = df["PortalRunStatus"].fillna("Unknown")

            print("Data loaded successfully.")
            return df

        except Exception as e:
            raise RuntimeError(f"Error loading Excel data: {e}")

    # -------------------------------------------------------------------------
    def aggregate_data(self, df):
        """Aggregate counts by Market and Status, including totals."""
        summary_data = []

        for market in df["Prctc"].unique():
            market_data = df[df["Prctc"] == market]
            counts = {status: (market_data["PortalRunStatus"] == status).sum()
                      for status in self.status_categories}
            total = sum(counts.values())
            summary_data.append([market, total] + list(counts.values()))

        columns = ["Market", "Total"] + self.status_categories
        summary_df = pd.DataFrame(summary_data, columns=columns)

        # Add ALL Markets total row
        total_row = ["ALL Markets"] + summary_df.iloc[:, 1:].sum().tolist()
        summary_df.loc[len(summary_df)] = total_row

        print("Aggregation complete.")
        return summary_df

    # -------------------------------------------------------------------------
    def write_report(self, summary_df):
        """Write formatted summary to Excel."""
        try:
            wb = load_workbook(self.file_path)
            if self.sheet_name in wb.sheetnames:
                del wb[self.sheet_name]

            ws = wb.create_sheet(self.sheet_name, 0)

            # Write header row
            ws.append(summary_df.columns.tolist())
            for cell in ws[1]:
                cell.font = self.bold_font
                cell.fill = self.header_fill
                cell.border = self.thin_border
                cell.alignment = self.center_align

            # Write data rows
            for _, row in summary_df.iterrows():
                ws.append(row.tolist())

            # Style ALL Markets row
            for cell in ws[ws.max_row]:
                cell.fill = self.green_fill
                cell.font = self.bold_font
                cell.border = self.thin_border
                cell.alignment = self.center_align

            # Apply borders & alignment to all cells
            for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=1, max_col=ws.max_column):
                for cell in row:
                    cell.border = self.thin_border
                    cell.alignment = self.center_align

            # Auto-adjust column widths
            for column_cells in ws.columns:
                length = max(len(str(cell.value)) if cell.value else 0 for cell in column_cells)
                ws.column_dimensions[column_cells[0].column_letter].width = min(length + 4, 60)

            # Freeze header row
            ws.freeze_panes = "A2"

            wb.save(self.file_path)
            print(f"Report successfully written to sheet '{self.sheet_name}'.")

        except PermissionError:
            raise PermissionError(f"Permission denied: Please close {self.file_path} before running.")
        except Exception as e:
            raise RuntimeError(f"Failed to write report: {e}")

    # -------------------------------------------------------------------------
    def run(self):
        """Execute the complete report generation."""
        try:
            self.wait_for_file()
            df = self.load_data()
            summary_df = self.aggregate_data(df)
            self.write_report(summary_df)
            print("Report generation completed successfully.")
        except Exception as e:
            print(f"Error: {e}")
            sys.exit(1)


# -------------------------------------------------------------------------
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python generate_report.py <excel_file_path>")
        sys.exit(1)

    file_path = sys.argv[1]
    ReportGenerator(file_path).run()
