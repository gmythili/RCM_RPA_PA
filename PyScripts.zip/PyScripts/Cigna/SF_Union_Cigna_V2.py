import pandas as pd
import time
import sys
import os
from datetime import datetime
from openpyxl import load_workbook
from openpyxl.utils.dataframe import dataframe_to_rows
import re

# ============================================================== #
# CONFIGURATION
# ============================================================== #
skip_markets = ["UL", "UM", "NE", "UG", "CW", "Other"]

# ============================================================== #
# UTILITY: Wait for file to be ready
# ============================================================== #
def wait_for_file(filepath, timeout=20):
    print(f"Waiting for file: {filepath}")

    if os.path.basename(filepath).startswith("~$"):
        print(f"Error: {filepath} is a temporary Excel lock file.")
        sys.exit(1)

    start_time = time.time()

    while True:
        if os.path.exists(filepath):
            try:
                with open(filepath, 'rb'):
                    print(f"File ready: {filepath}")
                    return
            except Exception:
                pass

        if time.time() - start_time > timeout:
            print(f"Timeout: File not accessible after {timeout} seconds -> {filepath}")
            sys.exit(1)

        time.sleep(1)

# ============================================================== #
# UTILITY: Clean email
# ============================================================== #
def clean_email(e):
    if pd.isna(e):
        return ''
    return re.sub(r'\s+', '', str(e).lower())

# ============================================================== #
# STARTUP
# ============================================================== #
print("Starting SF_Union_Portals Cigna processing script...\n")
time.sleep(2)

# ============================================================== #
# COMMAND-LINE ARGUMENTS
# ============================================================== #
if len(sys.argv) != 3:
    print("Usage: python SF_Union_Portals_Cigna.py <salesforce_excel_path> <cigna_csv_path>")
    sys.exit(1)

sf_path = sys.argv[1]
cigna_path = sys.argv[2]

wait_for_file(sf_path)
wait_for_file(cigna_path)

try:
    # ============================================================== #
    # READ CIGNA CSV
    # ============================================================== #
    print("Reading Cigna CSV...")

    try:
        cigna_df = pd.read_csv(cigna_path, encoding='utf-8')
    except UnicodeDecodeError:
        cigna_df = pd.read_csv(cigna_path, encoding='latin1')

    cigna_df.columns = cigna_df.columns.str.strip().str.upper()

    required_cols = ['EMAIL', 'USER ID']
    for col in required_cols:
        if col not in cigna_df.columns:
            print(f"ERROR: Column '{col}' not found in Cigna CSV!")
            sys.exit(1)

    # Clean emails
    cigna_df['EMAIL'] = cigna_df['EMAIL'].apply(clean_email)

    # Drop duplicate emails (keep first)
    cigna_df = cigna_df.drop_duplicates(subset=['EMAIL'])

    # Create lookup dictionary
    cigna_lookup = dict(zip(cigna_df['EMAIL'], cigna_df['USER ID']))

    # ============================================================== #
    # PROCESS SALESFORCE EXCEL
    # ============================================================== #
    work_book = load_workbook(sf_path)
    all_sheets = work_book.sheetnames
    sheets_to_process = [s for s in all_sheets if s not in skip_markets]

    emailvalue_rows = []

    for sheet_name in sheets_to_process:

        print(f"\nProcessing sheet: {sheet_name}")

        sf_df = pd.read_excel(sf_path, sheet_name=sheet_name, engine='openpyxl')
        sf_df.columns = sf_df.columns.str.strip().str.upper()

        if 'EMAIL' not in sf_df.columns:
            print(f"'EMAIL' column not found in {sheet_name}. Skipping.")
            continue

        # Clean emails
        sf_df['EMAIL'] = sf_df['EMAIL'].apply(clean_email)

        # =========================
        # VECTORISED USER ID MAPPING
        # =========================
        sf_df['CIGNA'] = sf_df['EMAIL'].map(cigna_lookup)

        # Replace NaN with success message
        sf_df['CIGNA'] = sf_df['CIGNA'].fillna('Success - User not found')

        # =========================
        # WRITE BACK TO EXCEL
        # =========================
        ws = work_book[sheet_name]
        ws.delete_rows(1, ws.max_row)

        for row in dataframe_to_rows(sf_df, index=False, header=True):
            ws.append(row)

        # =========================
        # PREPARE ACTIVE USER OUTPUT
        # =========================
        has_fname = 'FN' in sf_df.columns
        has_lname = 'LN' in sf_df.columns

        matched_df = sf_df[sf_df['CIGNA'] != 'Success - User not found']

        for idx, row in matched_df.iterrows():

            email = row['EMAIL']
            user_id = row['CIGNA']
            first_name = row['FN'] if has_fname else ''
            last_name = row['LN'] if has_lname else ''
            row_number = idx + 2
            col_number = sf_df.columns.get_loc('CIGNA') + 1

            emailvalue_rows.append([
                email,
                user_id,
                row_number,
                col_number,
                sheet_name,
                first_name,
                last_name
            ])

    # Save updated Excel
    work_book.save(sf_path)
    print("\nAll sheets updated successfully.")

    # ============================================================== #
    # CREATE OUTPUT CSV
    # ============================================================== #
    if emailvalue_rows:

        timestamp = datetime.now().strftime("%d%m%Y")
        output_path = os.path.join(
            os.path.dirname(sf_path),
            f"{timestamp}_CignaActive.csv"
        )

        df_out = pd.DataFrame(
            emailvalue_rows,
            columns=[
                'Email',
                'User ID',
                'Row',
                'Column',
                'Sheet',
                'First Name',
                'Last Name'
            ]
        )

        df_out = df_out.drop_duplicates(subset=['Email', 'User ID', 'Sheet'])

        df_out.to_csv(output_path, index=False)

        print(f"CSV saved: {output_path}")

    else:
        print("No active USER IDs found. CSV not created.")

except Exception as e:
    print("An error occurred:", str(e))
    sys.exit(1)
