import pandas as pd
import sys
from datetime import datetime
import warnings
import os

# ===========================================================
# Suppress FutureWarnings
# ===========================================================
warnings.simplefilter(action='ignore', category=FutureWarning)

# ===========================================================
# Check if file path argument is provided
# ===========================================================
if len(sys.argv) < 2:
    print("Usage: python script_name.py <excel_file_path>")
    sys.exit(1)

# Get the Excel file path from command line arguments
file_path = sys.argv[1]

# ===========================================================
# Load the Excel sheet
# ===========================================================
df = pd.read_excel(file_path)

# ===========================================================
# Drop the 'Roles' column if it exists
# ===========================================================
if 'Roles' in df.columns:
    df = df.drop(columns=['Roles'])

# ===========================================================
# Remove duplicate rows based on 'User ID', keeping the first occurrence
# ===========================================================
if 'User ID' in df.columns:
    df_unique = df.drop_duplicates(subset=['User ID'])
else:
    df_unique = df  # If no 'User ID' column, just keep original

# ===========================================================
# Generate output filename with current date in same folder as input
# ===========================================================
current_date = datetime.now().strftime('%Y%m%d')
input_folder = os.path.dirname(file_path)  # Get folder of input file
output_file = os.path.join(input_folder, f"{current_date}_Availity.xlsx")

# ===========================================================
# Save to Excel
# ===========================================================
df_unique.to_excel(output_file, index=False)

print(f"Data cleaned and saved to '{output_file}'")
